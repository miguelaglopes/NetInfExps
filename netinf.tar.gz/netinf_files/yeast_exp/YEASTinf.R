## runs the network inference algorithms ##
library(GCnetinf)
source("../R_files/literature.R")
load("YEASTinf3-data.Rdata")
predictionsALL=list()
netinfMethods=c("mi","aracne","clr","mrmr","cmim","mimr","rf","lars")
for (d in 1:length(exprdata)){
	print(paste("network",d))
	predictionsALL[[d]]=list()
	for (n in 1:length(exprdata[[d]])){
		print(paste("time series",n))
		exprdata2=exprdata[[d]][[n]]
		predictions=netinf1l(exprdata2, Methods=netinfMethods)
		predictions[[length(predictions)+1]]=tryCatch({simone.function(exprdata2,cluster=TRUE)}, error = function(e) {"error"})
		predictions[[length(predictions)+1]]=tryCatch({g1dbn.function(exprdata2, alphavalues=0.7)}, error = function(e) {"error"})
		predictions[[length(predictions)+1]]=tryCatch({genenet.function(exprdata2)}, error = function(e) {"error"})
		predictions[[length(predictions)+1]]=tryCatch({rf.static(exprdata2)}, error = function(e) {"error"})
		gc.scores=gcausal2(exprdata2)
		predictions[[length(predictions)+1]]=gc.scores
		predictions[[length(predictions)+1]]=gcausal2(exprdata2,sibling.filter=TRUE)		
		predictions[[length(predictions)+1]]=gcausal3(exprdata2,rank.method="static",search.speed=1)		
		predictions[[length(predictions)+1]]=gcausal3(exprdata2,rank.method="temp",rank.matrix=gc.scores,search.speed=1)
		predictions[[length(predictions)+1]]=gcausal3(exprdata2,rank.method="temp",rank.matrix=gc.scores,search.speed=3)
		predictions[[length(predictions)+1]]=gcausal3(exprdata2,rank.method="temp",rank.matrix=gc.scores,search.speed=5)
		predictions[[length(predictions)+1]]=gcausal3(exprdata2,rank.method="temp",rank.matrix=gc.scores,search.speed=3,sibling.filter=TRUE)
		## put gc methods first ##
		predictionsALL[[d]][[n]]=predictions[c(13:19),(1:12)]
		}}
save(file="YEASTinf.Rdata", list=c("predictionsALL","interaction.mat", "indnets"))