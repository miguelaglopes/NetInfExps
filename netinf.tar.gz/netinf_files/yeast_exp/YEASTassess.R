### network inference assessment 
### assess with monte carlo, as the number of positive instances in the networks is low

load("YEASTinf-data.Rdata")
for (i in 1:length(interaction.mat)){
	diag(interaction.mat[[i]])=0}	
### do Monte Carlo simulations ### 
Pall=unique(unlist(lapply(interaction.mat, function(x) length(which(x!=0)))))
N=length(interaction.mat[[1]])-nrow(interaction.mat[[1]])
nsimul=100000
montecarlo=list()
for (i in 1:length(Pall)){
	print(i)
	temp=NULL
	for (j in 1:nsimul){
		print(j)
		test=numeric(N)+abs(rnorm(N,0,1))
		y=numeric(N)
		y[1:Pall[i]]=1
		temp=c(temp,auprc.ap( test, y))}}
	montecarlo[[i]]=temp
save(file="auprc.montecarlo.Rdata", list=c("montecarlo", "interaction.mat"))

### once the file above have been computed
### start from here ###
library(pranker)
load("YEASTinf.Rdata")
load("auprc.montecarlo.Rdata")
source("../R_files/plots-fun.R")
## number of positives and negatives in the gold standard 
Pall=unique(unlist(lapply(interaction.mat, function(x) length(which(x!=0)))))
N=length(interaction.mat[[1]])-nrow(interaction.mat[[1]])

## in the predictions, substitute NAs with the minimum ##
for (i in 1:length(predictionsALL)){
	for (j in 1:length(predictionsALL[[i]])){
		for (k in 1:length(predictionsALL[[i]][[j]])){
			indNA=which(is.na(predictionsALL[[i]][[j]][[k]]))
			if (length(indNA)>0){
				predictionsALL[[i]][[j]][[k]][indNA]=min(predictionsALL[[i]][[j]][[k]][-indNA])}}}}

## add a borda count combination of temporal methods (given by indMETA) , plus random 
indMETA=c(1,5,8,9,10,11,12,13,14,15,16,17)
for (i in 1:length(predictionsALL)){
	for (j in 1:length(predictionsALL[[i]])){
		predictionsMETA=mat.or.vec(nrow(interaction.mat[[j]]),nrow(interaction.mat[[j]]))
		for (k in indMETA){
			predictionsMETA=predictionsMETA+rank(predictionsALL[[i]][[j]][[k]])
			}
		predictionsALL[[i]][[j]][[ length(predictionsALL[[i]][[j]])+1 ]]=predictionsMETA
		predictionsALL[[i]][[j]][[ length(predictionsALL[[i]][[j]])+1 ]]=predictionsMETA*0+rnorm(length(predictionsALL[[1]][[1]][[1]]),0,1)
		}}
## methods names: 
methodsnames=c("gc2","gc2+cf","gc3-sr1","gc3-dr1","gc3-dr3","gc3-dr5","gc3-dr3+cf",
"mi","aracne","clr","mrmr","cmim","mimr","rf","lasso","simone","g1dbn","genenet (static)","rf (static)","meta","random")

## do 2 analysis: all networks individually - approach A
## and borda count combination of the 11 time series - approach B 

## approach A
scoresALLmc=list()
for (m in 1:length(methodsnames)){
	print(m)
	scoresALLmc[[m]]=NA
	for(d in 1:length(predictionsALL)){
		for (n in 1:length(predictionsALL[[1]])){
			pred=predictionsALL[[d]][[n]][[m]]
			pred[which(pred==-Inf)]=min(pred[-which(pred==-Inf)],na.rm=TRUE)	
			diag(pred)=min(pred)
			pred=pred-min(pred)			
			mc=which(Pall==length(which(interaction.mat[[d]]!=0)))		
			temp=auprc.ap( pred,interaction.mat[[d]])
			temp=length(which(temp<montecarlo[[mc]]))/length(montecarlo[[mc]])
			scoresALLmc[[m]]=c(scoresALLmc[[m]],temp)			
			}}
	scoresALLmc[[m]]=scoresALLmc[[m]][-1]
	scoresALLmc[[m]]=qnorm(scoresALLmc[[m]],0,1,lower.tail=FALSE)}
temp=NULL
for (i in 1:length(scoresALLmc)){
	temp=cbind(temp, scoresALLmc[[i]])}
scoresALLmc=temp
colnames(scoresALLmc)=methodsnames

## approach B
predictionsC=list()
for (i in 1:length(predictionsALL[[1]][[1]])){
	predictionsC[[i]]=list()
	for (j in 1:length(predictionsALL[[1]])){
		predictionsC[[i]][[j]]=predictionsALL[[1]][[1]][[1]]*0
		for (k in 1:length(predictionsALL)){
			predictionsC[[i]][[j]][,]=predictionsC[[i]][[j]][,]+rank(predictionsALL[[k]][[j]][[i]])}}}
scoresCmc=list()
for (m in 1:length(methodsnames)){
	print(m)
	scoresCmc[[m]]=NA
	for(d in 1:length(predictionsC[[m]])){
		pred=predictionsC[[m]][[d]]
		pred[which(pred==-Inf)]=min(pred[-which(pred==-Inf)],na.rm=TRUE)
		pred[which(is.na(pred))]=min(pred,na.rm=TRUE)
		diag(pred)=min(pred)
		pred=pred-min(pred)
		
		mc=which(Pall==length(which(interaction.mat[[d]]!=0)))		
		temp=auprc.ap( pred,interaction.mat[[d]])
		temp=length(which(temp<montecarlo[[mc]]))/length(montecarlo[[mc]])
		scoresCmc[[m]]=c(scoresCmc[[m]],temp)
		}
	scoresCmc[[m]]=scoresCmc[[m]][-1]
	scoresCmc[[m]]=qnorm(scoresCmc[[m]],0,1,lower.tail=FALSE)}
temp=NULL
for (i in 1:length(scoresCmc)){
	temp=cbind(temp, scoresCmc[[i]])}
scoresCmc=temp
colnames(scoresCmc)=methodsnames

### do plots ## 
## does significance plot and gets order of methods for subsequent boxplot
## combined time series
ind=signif.heatmap(scoresCmc, toupper(methodsnames), "yeast-sign-comb.pdf", "Comparison of AUPRC values \n Wilcoxon signed rank test\n Yeast data (combined time series)")
ind=rev(ind)
ind=c(1:7,setdiff(ind,1:7))

scoresUSE=scoresCmc[,ind]
methodsnamesUSE=toupper(methodsnames[ind])
outfile="yeast-boxplots-comb.pdf"
maintitle="Yeast network inference (100 50-gene networks) \n (combined time series)"
pdf(outfile,width=10, height=8)
par(mar=c(10.5,4.1,4.1,2.1))
boxplot(scoresUSE, outline=FALSE,main=maintitle, xaxt = "n", ylab="AUPRC z-scores")
axis(1, at=1:length(methodsnamesUSE), labels=methodsnamesUSE,las=2)	
dev.off()

## individual time series
ind=signif.heatmap(scoresALLmc, toupper(methodsnames), "yeast-sign-all.pdf", "Comparison of AUPRC values \n Wilcoxon signed rank test\n Yeast data (individual time series)")
ind=rev(ind)
ind=c(1:7,setdiff(ind,1:9))
scoresUSE=scoresALLmc[,ind]
methodsnamesUSE=toupper(methodsnames[ind])
outfile="yeast-boxplots-all.pdf"
maintitle="Yeast network inference (100 50-gene networks) \n (individual time series)"
pdf(outfile,width=10, height=8)
par(mar=c(10.5,4.1,4.1,2.1))
boxplot(scoresUSE, outline=FALSE,main=maintitle, xaxt = "n", ylab="AUPRC z-scores")
axis(1, at=1:length(methodsnamesUSE), labels=methodsnamesUSE,las=2)	
dev.off()

save(file="YEASTassess.Rdata",list=ls())