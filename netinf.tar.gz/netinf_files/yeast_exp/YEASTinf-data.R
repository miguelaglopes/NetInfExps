## randomly select 1000 sets of 50 genes
## select the top 100 gene sets, with the most regulations
load("YEASTdata.Rdata")
numnets=1000
ngenes=50
indnets=list()
numregs=numeric(numnets)
for (i in 1:numnets){
	indnets[[i]]=sample(1:ncol(interaction.adj),ngenes)
	numregs[i]=length(which(interaction.adj[indnets[[i]], indnets[[i]]]!=0))}
indnets=indnets[sort(numregs, decreasing=TRUE, index.return=TRUE)[[2]][1:100]]
exprdata=list()
for (i in 1:length(exprdata_all)){
	exprdata[[i]]=list()
	for (j in 1:length(indnets)){
		exprdata[[i]][[j]]=exprdata_all[[i]][indnets[[j]],]}}
interaction.mat=list()
for (j in 1:length(indnets)){
	interaction.mat[[j]]=interaction.adj[indnets[[j]],indnets[[j]]]}
save(file="YEASTinf-data.Rdata", list=c("exprdata","interaction.mat", "indnets"))