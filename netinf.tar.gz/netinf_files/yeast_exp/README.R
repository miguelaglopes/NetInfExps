## prepares the datasets #
source("YEASTdata.R")
## generates networks for inference #
source("YEASTinf-data.R")
## network inference 
source("YEASTinf.R")
## network inference assessment 
source("YEASTassess.R")