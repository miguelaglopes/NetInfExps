### load the time series and gold standard , save them in a single file 
### only select genes associated with a regulation in the gold standard 
datasets_files=c(
"datasets/yeast/GDS2350/DATA_1new.Rdata",
"datasets/yeast/GDS2350/DATA_2new.Rdata",
"datasets/yeast/E-GEOD-24771/DATA1new.Rdata",
"datasets/yeast/E-GEOD-24771/DATA2new.Rdata",
"datasets/yeast/E-GEOD-24771/DATA3new.Rdata",
"datasets/yeast/E-GEOD-24771/DATA4new.Rdata",
"datasets/yeast/E-GEOD-24771/DATA5new.Rdata",
"datasets/yeast/E-GEOD-24771/DATA6new.Rdata",
"datasets/yeast/E-GEOD-24771/DATA7new.Rdata",
"datasets/yeast/E-GEOD-24771/DATA8new.Rdata",
"datasets/yeast/E-GEOD-24771/DATA9new.Rdata")
## select common genes for all datasets ##
load(datasets_files[1])
geneskeep=rownames(interaction.adj)
exprdata_all=list()
interaction_adj_all=list()
exprdata_all[[1]]=exprdata
interaction_adj_all[[1]]=interaction.adj
for (d in 2:length(datasets_files)){
	load(datasets_files[d])
	exprdata_all[[d]]=exprdata
	interaction_adj_all[[d]]=interaction.adj
	geneskeep=intersect(geneskeep, rownames(interaction.adj))
	}
exprdata_all2=list()
interaction_adj_all2=list()
for (d in 1:length(datasets_files)){
	ind.keep=sapply(geneskeep, function(x) which(x==rownames(interaction_adj_all[[d]])))
	exprdata_all2[[d]]=exprdata_all[[d]][ind.keep,]
	interaction_adj_all2[[d]]=interaction_adj_all[[d]][ind.keep,ind.keep]
	}
interaction.adj=interaction_adj_all2[[d]]
exprdata_all=list()
for (d in 1:length(datasets_files)){
	exprdata_all[[d]]=exprdata_all2[[d]]
	ind.remove=which(interaction.adj*t(interaction.adj)!=0)
	if (length(ind.remove)>0){
		interaction.adj=interaction.adj[-ind.remove, -ind.remove]
		}}
diag(interaction.adj)=0
save(file="YEASTdata.Rdata", list=c("exprdata_all", "interaction.adj"))