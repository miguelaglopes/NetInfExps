### plots functions 

## heatmap of significance analysis 
## scoresTHIS (matrix of scores, methods in columns)
signif.heatmap<-function(scoresTHIS, methodsnames, outfile, maintitle){
pvalues.mat=mat.or.vec(length(methodsnames), length(methodsnames))
directW.mat=mat.or.vec(length(methodsnames), length(methodsnames))
for (i in 1:length(methodsnames)){
	for (j in 1:length(methodsnames)){
		pvalues.mat[i,j]=wilcox.test( scoresTHIS[,i], scoresTHIS[,j], paired=TRUE )[[3]]
		directW.mat[i,j]=wilcoxfun(  scoresTHIS[,i], scoresTHIS[,j] )
		}}
diag(pvalues.mat)=0.5
indD=which(directW.mat>0)
indP=list()
pvLABS=c(0.1, 0.01, 0.001, 0.0001)
for (p in 1:length(pvLABS)){
	indP[[p]]=which( pvalues.mat<pvLABS[p])}
pvalues.matC=pvalues.mat*0
for (p in 1:length(indP)){
	pvalues.matC[ indP[[p]] ]= p}
pvalues.matC2=pvalues.matC
for (i in 1:length(indP)){
	ind=which( pvalues.matC[-indD] == i)
	pvalues.matC2[-indD][ind]=pvalues.matC2[-indD][ind]+4}
diag(pvalues.matC2)=0
cols1=c(
"#FF9999",
"#FF3333",
"#CC0000",
"#660000")
cols2=c(
"#99CCFF",
"#3399FF",
"#0066CC",
"#003366")
cols=c("#FFFFFF", cols1, cols2)
legendlabs=c("pv > 0.1",
"pv < 0.1",
"pv < 0.01",
"pv < 0.001",
"pv < 0.0001 (line < column)",
"pv < 0.1",
"pv < 0.01",
"pv < 0.001",
"pv < 0.0001 (line > column)")
library(fields)
pdf(outfile,width=9,height=8)
paroma=par()$oma
paroma[c(1,2)]=c(4.5,4.5)
paroma[3]=4
paroma[4]=9
par(oma=paroma)
par(mar=c(5,5,1,5))
temp=pvalues.matC2
temp[which(temp>4)]=temp[which(temp>4)]*(-1)
indNEW=sort(apply(temp, 1, mean), decreasing=FALSE, index.return=TRUE)[[2]]
xlabels=methodsnames
image(pvalues.matC2[indNEW, indNEW], axes=FALSE, col=c(cols))
title(main=maintitle, outer=TRUE)
axis(2, at=(0:(length(xlabels)-1))/(length(xlabels)-1), labels=xlabels[indNEW], tick=FALSE, las=2)
axis(1, at=(0:(length(xlabels)-1))/(length(xlabels)-1), labels=xlabels[indNEW], tick=FALSE, las=2)
image.plot(pvalues.matC2[indNEW, indNEW], col=c(cols), axis.args=list( at=(1:9)*(7/8),labels=legendlabs), legend.only=T, legend.width=1)
dev.off()
return(indNEW)} ## returns index

### gets the "direction" of the W statistic
### the R function wilcox.test only outputs the absolute value
### if W is positive, x is higher than y 
wilcoxfun<-function(x,y){
diffs=abs(x-y)
signs=sign(x-y)
indREM=which(diffs==0)
diffs[indREM]=0
signs[indREM]=0
ranks=rank(diffs)
W=sum(ranks*signs)
return(sign(W))
}

