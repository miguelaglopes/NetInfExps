## static: Genie3 and Genenet ##

## genie3 ## 
## sometimes crashes!
#genie3.function <-function(exprdata){
#	prediction=get.weight.matrix(exprdata) ## source genie3
#	return(prediction)}

rf.static <-function(exprdata){
	prediction=mat.or.vec(nrow(exprdata),nrow(exprdata))
	checkseq=1:100	
	for (y in 1:nrow(exprdata)){
		if (any(checkseq==round(y/nrow(exprdata),2)*100)){
			checkseq=checkseq[-which(checkseq==round(y/nrow(exprdata),2)*100)]
			cat(paste(round(y/nrow(exprdata),2)*100, "% ", sep=""))}		
		target=exprdata[y,]
		predictors=exprdata[-y,]
		rownames(predictors)=1:nrow(predictors)	
		rf.importance="IncNodePurity"
		rf.mtry=round(sqrt(nrow(exprdata)))
		rf.ntrees=1000
		rf <- randomForest(t(predictors), target, mtry=rf.mtry, ntree=rf.ntrees, importance=TRUE)
		im <- importance(rf)[,rf.importance]
		prediction[-y,y]=im}
	return(prediction)}


## Genenet ##
genenet.function <-  function( exprdata){
	library(GeneNet)
	pcor <- ggm.estimate.pcor( t(exprdata) )
	p <- nrow(exprdata)
	edges <- network.test.edges(pcor,direct=TRUE,plot=FALSE)
	net <- extract.network(edges, method.ggm="number", method.dir="all", cutoff.ggm=nrow(edges))
	prediction=mat.or.vec(p, p)
	for (i in 1:nrow(net)){
		if (as.character(net[i,11]) == "1to2") {
			node_in=net[i,2]
			node_out=net[i,3]
			prediction[node_in, node_out]=1-net[i,4]
			}
		if (as.character(net[i,11]) == "2to1") {
			node_in=net[i,3]
			node_out=net[i,2]
			prediction[node_in, node_out]=1-net[i,4]
			}
		if (as.character(net[i,11]) == "undirected") {
			node_in=net[i,2]
			node_out=net[i,3]
			prediction[node_in, node_out]=1-net[i,4]
			prediction[node_out, node_in]=1-net[i,4]
			}
		}	
	return(prediction)
	}

## one lag methods below ## 

## simone ##
simone.function<-function(exprdata,cluster){
	library(simone)
	n.genes=nrow(exprdata)
	if (cluster==TRUE){	
		edges.max=((n.genes*n.genes)-n.genes)
		control <- setOptions(edges.max=edges.max, clusters.qmax=2)
		sim.out=simone(t(exprdata), type="time-course", clustering=TRUE, control=control)
		}
	if (cluster==FALSE){
		sim.out=simone(t(exprdata), type="time-course")
		}
	## interactions go from row to column! does not say on the documentation, but I figured it running the demo
	prediction=mat.or.vec(n.genes,n.genes)
	for (i in 1:length(sim.out[[1]])){
		ind=which(sim.out[[1]][[i]]!=0)
		prediction[ind]=prediction[ind]+sim.out[[1]][[i]][ind] ## sum values ##
		}
	return(abs(prediction))
	}
	## prediction gives a score to each edge, indicating how many times it has appeared in the lasso path##
	
### G1DBN ###
g1dbn.function<-function(exprdata, alphavalues){
	library(G1DBN)
	n.genes=nrow(exprdata)
	# 1st step DBNScoreStep1 allows to
	# reduce the number of potential edges, DBNScoreStep2 performs the
	# last step selection. The smallest score are the most significant 
	# the threshold alpha1 (alphavalues) should change from 0 to 1 (to more restrictive to less restrictive)
	# in the authors document, in the experimental session, alpha1 is set to 0.7
	a=DBNScoreStep1(t(exprdata),method="ls",predPosition=NULL,targetPosition=NULL)
	prediction=list()
	for (i in 1:length(alphavalues)){	
		alpha1=alphavalues[i]
		prediction[[i]]=DBNScoreStep2(a[[1]], t(exprdata),alpha1=alpha1, method="ls",predPosition=NULL,targetPosition=NULL)
		## these are p values, convert to log ## (as in Fishers's method)
		prediction[[i]]=-log(prediction[[i]]) # higher values mean higher confidence
		}
	# replace NAs with 0
	for (i in 1:length(prediction)){
		prediction[[i]][ which(is.na(prediction[[i]])) ]=0
		}
	prediction.total=mat.or.vec(n.genes,n.genes)
	for (i in 1:length(prediction)){
		prediction.total=prediction.total+prediction[[i]]
		}	
	## transpose the matrix, see documentation
	prediction.total=t(prediction.total)
	return(prediction.total)
	}