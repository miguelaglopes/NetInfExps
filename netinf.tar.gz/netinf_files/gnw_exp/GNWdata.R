## opens and saves data into a single file 
nseq=seq(20,200,20)
exprdata.all2=list()
for (n in 1:length(nseq)){
	nTHIS=nseq[n]
	load("dataset/n300.Rdata")  ## this file is from the original set of time series
	for(d in 1:length(exprdata.all)){
		indBEGIN=(ncol(exprdata.all[[d]])/2)-nTHIS/2
		indEND=(ncol(exprdata.all[[d]])/2)+nTHIS/2
		exprdata.all[[d]]=exprdata.all[[d]][,indBEGIN:(indEND-1)]
		}
	exprdata.all2[[n]]=exprdata.all
	}
load("n300.Rdata")  ## this file is from the original set of time series
exprdata.all2[[n+1]]=exprdata.all	
exprdata=exprdata.all2
interaction.mat=interaction.mat.all
save(file="GNWdata.Rdata", list=c("exprdata","interaction.mat"))