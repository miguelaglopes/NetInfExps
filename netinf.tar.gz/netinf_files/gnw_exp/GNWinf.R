## runs the network inference algorithms ##
library(GCnetinf)
source("../R_files/literature.R")
library(tseries)
library(ppcor)
library(randomForest)
library(lars)
load("GNWdata.Rdata")
netinfMethods=c("mi","aracne","clr","mrmr","cmim","mimr","rf","lars")
predictionsALL=list()
for (n in 1:length(exprdata)){
	print(paste("time points",n))
	predictionsALL[[n]]=list()
	for (d in 1:length(exprdata[[n]])){
		print(paste("dataset",d))
		exprdata2=exprdata[[n]][[d]]
		exprdata2=t(apply(exprdata2, 1, as.numeric))		
		predictions=netinf1l(exprdata2, Methods=netinfMethods)
		predictions[[length(predictions)+1]]=tryCatch({simone.function(exprdata2,cluster=TRUE)}, error = function(e) {"error"})
		predictions[[length(predictions)+1]]=tryCatch({g1dbn.function(exprdata2, alphavalues=0.7)}, error = function(e) {"error"})
		predictions[[length(predictions)+1]]=tryCatch({genenet.function(exprdata2)}, error = function(e) {"error"})
		predictions[[length(predictions)+1]]=tryCatch({rf.static(exprdata2)}, error = function(e) {"error"})
		gc.scores=gcausal2(exprdata2)
		predictions[[length(predictions)+1]]=gc.scores
		predictions[[length(predictions)+1]]=gcausal2(exprdata2,sibling.filter=TRUE)		
		predictions[[length(predictions)+1]]=gcausal3(exprdata2,rank.method="static",search.speed=1)		
		predictions[[length(predictions)+1]]=gcausal3(exprdata2,rank.method="temp",rank.matrix=gc.scores,search.speed=1)
		predictions[[length(predictions)+1]]=gcausal3(exprdata2,rank.method="temp",rank.matrix=gc.scores,search.speed=3)
		predictions[[length(predictions)+1]]=gcausal3(exprdata2,rank.method="temp",rank.matrix=gc.scores,search.speed=5)
		predictions[[length(predictions)+1]]=gcausal3(exprdata2,rank.method="temp",rank.matrix=gc.scores,search.speed=3,sibling.filter=TRUE)
		## put gc methods first ##
		predictionsALL[[d]][[n]]=predictions[c(13:19),(1:12)]
		predictionsALL[[n]][[d]]=predictions
		}}
save(file="GNWinf.Rdata", list=c("predictionsALL","interaction.mat"))
		
		