library(pranker)
load("GNWdata.Rdata")
## compute AUPRC parameters (beta distribution approximation) ##
auprc.params=list()
for (i in 1:length(interaction.mat)){
	print(i)
	diag(interaction.mat[[i]])=0
	N=length(interaction.mat[[i]])-nrow(interaction.mat[[i]])
	P=length(which(interaction.mat[[i]]!=0))
	auprc.params[[i]]=null.params(N,P)}
save(file="auprc.params.Rdata", list=c("auprc.params", "interaction.mat"))

### once the file above have been computed
### start from here ###
library(pranker)
load("auprc.params.Rdata")
load("GNWinf.Rdata")
source("../R_files/plots-fun.R")

## in the predictions, substitute NAs with the minimum ##
for (i in 1:length(predictionsALL)){
	for (j in 1:length(predictionsALL[[i]])){
		for (k in 1:length(predictionsALL[[i]][[j]])){
			indNA=which(is.na(predictionsALL[[i]][[j]][[k]]))
			if (length(indNA)>0){
				predictionsALL[[i]][[j]][[k]][indNA]=min(predictionsALL[[i]][[j]][[k]][-indNA])}}}}

## add a borda count combination of temporal methods (given by indMETA) , plus random 
indMETA=c(1,5,8,9,10,11,12,13,14,15,16,17)
for (i in 1:length(predictionsALL)){
	for (j in 1:length(predictionsALL[[i]])){
		predictionsMETA=mat.or.vec(nrow(interaction.mat[[j]]),nrow(interaction.mat[[j]]))
		for (k in indMETA){
			predictionsMETA=predictionsMETA+rank(predictionsALL[[i]][[j]][[k]])
			}
		predictionsALL[[i]][[j]][[ length(predictionsALL[[i]][[j]])+1 ]]=predictionsMETA
		predictionsALL[[i]][[j]][[ length(predictionsALL[[i]][[j]])+1 ]]=predictionsMETA*0+rnorm(length(predictionsALL[[1]][[1]][[1]]),0,1)
		}}
## methods names: 
methodsnames=c("gc2","gc2+cf","gc3-sr1","gc3-dr1","gc3-dr3","gc3-dr5","gc3-dr3+cf",
"mi","aracne","clr","mrmr","cmim","mimr","rf","lasso","simone","g1dbn","genenet (static)","rf (static)","meta","random")

## compute AUPRC z-scores ##
scores=list()
for(timepoints in 1:11){
print(timepoints)
scores[[timepoints]]=list()
for (m in 1:length(methodsnames)){
	print(m)
	scores[[timepoints]][[m]]=NA
	for(d in 1:length(predictionsALL[[timepoints]])){
		pred=predictionsALL[[timepoints]][[d]][[m]]
		pred[which(pred==-Inf)]=min(pred[-which(pred==-Inf)],na.rm=TRUE)
		pred[which(is.na(pred))]=min(pred,na.rm=TRUE)
		diag(pred)=min(pred)
		pred=pred-min(pred)
		scores[[timepoints]][[m]]=c(scores[[timepoints]][[m]],pranker(pred,interaction.mat[[d]],params=auprc.params[[d]])[[2]])
		}
	scores[[timepoints]][[m]]=scores[[timepoints]][[m]][-1]
	scores[[timepoints]][[m]]=qnorm(scores[[timepoints]][[m]],0,1,lower.tail=FALSE)}
	}

## do box plots of 20 and 300 time points ##
## do sign analysis for 300 time points ## 

signplots=c("gnw20-sign.pdf",
"gnw40-sign.pdf",
"gnw60-sign.pdf",
"gnw80-sign.pdf",
"gnw100-sign.pdf",
"gnw120-sign.pdf",
"gnw140-sign.pdf",
"gnw160-sign.pdf",
"gnw180-sign.pdf",
"gnw200-sign.pdf",
"gnw300-sign.pdf")
tpoints=c(20,40,60,80,100,120,140,160,180,200,300)
maintitle=paste("Comparison of AUPRC values \n Wilcoxon signed rank test\n GNW time series",tpoints,sep=" - ")
maintitle=paste(maintitle, "time points")

timepointsall=1:11
ind=list()
scoresALL=list()
for (timepoints in timepointsall){
scoresUSE=NULL
for (i in 1:length(scores[[timepoints]])){
	scoresUSE=cbind(scoresUSE, scores[[timepoints]][[i]])}
ind[[timepoints]]=signif.heatmap(scoresUSE, toupper(methodsnames), signplots[[timepoints]], maintitle[[timepoints]])
ind[[timepoints]]=rev(ind[[timepoints]])
ind[[timepoints]]=c(1:7,setdiff(ind[[timepoints]],1:7))
scoresALL[[timepoints]]=scoresUSE}

## box plots of 20 and 300 time points ## 
outfile="boxplots-GNW.pdf"
methodsnamesUSE=toupper(methodsnames[ind[[1]]])
pdf(outfile,width=10, height=15)
par(mfrow=c(2,1))
scoresUSE=scoresALL[[1]][,ind[[1]]]
maintitle="GNW network inference (100 50-gene networks) \n time series of 20 points"
par(mar=c(9.1,4.1,4.1,2.1))
boxplot(scoresUSE, outline=FALSE,main=maintitle, xaxt = "n", ylab="AUPRC z-scores", ylim=c(-2,11))
axis(1, at=1:length(methodsnames), labels=methodsnamesUSE,las=2)	
scoresUSE=scoresALL[[11]][,ind[[11]]]
methodsnamesUSE=toupper(methodsnames[ind[[11]]])
maintitle="time series of 300 points"
par(mar=c(9.1,4.1,4.1,2.1))
boxplot(scoresUSE, outline=FALSE,main=maintitle, xaxt = "n", ylab="AUPRC z-scores", ylim=c(-2,11))
axis(1, at=1:length(methodsnames), labels=methodsnamesUSE,las=2)	
dev.off()


## box plots of 40, 60 and 80 time points ## 
outfile="boxplots-GNW40-80.pdf"
methodsnamesUSE=toupper(methodsnames[ind[[2]]])
pdf(outfile,width=10, height=17)
par(mfrow=c(3,1))
scoresUSE=scoresALL[[2]][,ind[[2]]]
maintitle="GNW network inference (100 50-gene networks) \n time series of 40 points"
par(mar=c(9.1,4.1,4.1,2.1))
boxplot(scoresUSE, outline=FALSE,main=maintitle, xaxt = "n", ylab="AUPRC z-scores", ylim=c(-2,11))
axis(1, at=1:length(methodsnames), labels=methodsnamesUSE,las=2)	

scoresUSE=scoresALL[[3]][,ind[[3]]]
methodsnamesUSE=toupper(methodsnames[ind[[3]]])
maintitle="time series of 60 points"
par(mar=c(9.1,4.1,4.1,2.1))
boxplot(scoresUSE, outline=FALSE,main=maintitle, xaxt = "n", ylab="AUPRC z-scores", ylim=c(-2,11))
axis(1, at=1:length(methodsnames), labels=methodsnamesUSE,las=2)	

scoresUSE=scoresALL[[4]][,ind[[4]]]
methodsnamesUSE=toupper(methodsnames[ind[[4]]])
maintitle="time series of 80 points"
par(mar=c(9.1,4.1,4.1,2.1))
boxplot(scoresUSE, outline=FALSE,main=maintitle, xaxt = "n", ylab="AUPRC z-scores", ylim=c(-2,11))
axis(1, at=1:length(methodsnames), labels=methodsnamesUSE,las=2)	
dev.off()


## box plots of 100, 120 and 140 time points ## 
outfile="boxplots-GNW100-140.pdf"
methodsnamesUSE=toupper(methodsnames[ind[[5]]])
pdf(outfile,width=10, height=17)
par(mfrow=c(3,1))
scoresUSE=scoresALL[[5]][,ind[[5]]]
maintitle="GNW network inference (100 50-gene networks) \n time series of 100 points"
par(mar=c(9.1,4.1,4.1,2.1))
boxplot(scoresUSE, outline=FALSE,main=maintitle, xaxt = "n", ylab="AUPRC z-scores", ylim=c(-2,11))
axis(1, at=1:length(methodsnames), labels=methodsnamesUSE,las=2)	

scoresUSE=scoresALL[[6]][,ind[[6]]]
methodsnamesUSE=toupper(methodsnames[ind[[6]]])
maintitle="time series of 120 points"
par(mar=c(9.1,4.1,4.1,2.1))
boxplot(scoresUSE, outline=FALSE,main=maintitle, xaxt = "n", ylab="AUPRC z-scores", ylim=c(-2,11))
axis(1, at=1:length(methodsnames), labels=methodsnamesUSE,las=2)	

scoresUSE=scoresALL[[7]][,ind[[7]]]
methodsnamesUSE=toupper(methodsnames[ind[[7]]])
maintitle="time series of 140 points"
par(mar=c(9.1,4.1,4.1,2.1))
boxplot(scoresUSE, outline=FALSE,main=maintitle, xaxt = "n", ylab="AUPRC z-scores", ylim=c(-2,11))
axis(1, at=1:length(methodsnames), labels=methodsnamesUSE,las=2)	
dev.off()


## box plots of 160, 180 and 200 time points ## 
outfile="boxplots-GNW160-200.pdf"
methodsnamesUSE=toupper(methodsnames[ind[[8]]])
pdf(outfile,width=10, height=17)
par(mfrow=c(3,1))
scoresUSE=scoresALL[[8]][,ind[[8]]]
maintitle="GNW network inference (100 50-gene networks) \n time series of 160 points"
par(mar=c(9.1,4.1,4.1,2.1))
boxplot(scoresUSE, outline=FALSE,main=maintitle, xaxt = "n", ylab="AUPRC z-scores", ylim=c(-2,11))
axis(1, at=1:length(methodsnames), labels=methodsnamesUSE,las=2)	

scoresUSE=scoresALL[[9]][,ind[[9]]]
methodsnamesUSE=toupper(methodsnames[ind[[9]]])
maintitle="time series of 180 points"
par(mar=c(9.1,4.1,4.1,2.1))
boxplot(scoresUSE, outline=FALSE,main=maintitle, xaxt = "n", ylab="AUPRC z-scores", ylim=c(-2,11))
axis(1, at=1:length(methodsnames), labels=methodsnamesUSE,las=2)	

scoresUSE=scoresALL[[10]][,ind[[10]]]
methodsnamesUSE=toupper(methodsnames[ind[[10]]])
maintitle="time series of 200 points"
par(mar=c(9.1,4.1,4.1,2.1))
boxplot(scoresUSE, outline=FALSE,main=maintitle, xaxt = "n", ylab="AUPRC z-scores", ylim=c(-2,11))
axis(1, at=1:length(methodsnames), labels=methodsnamesUSE,las=2)	
dev.off()



