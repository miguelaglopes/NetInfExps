## prepares the datasets #
source("GNWdata.R")
## network inference 
source("GNWinf.R")
## network inference assessment 
source("GNWassess.R")